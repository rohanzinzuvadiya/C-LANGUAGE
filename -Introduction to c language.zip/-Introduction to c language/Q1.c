#include<stdio.h>
main(){
    printf("Name : rohan zinzuvadiya \n");
    printf("Age : 18 \n");
    printf("School :the school of science\n");
}
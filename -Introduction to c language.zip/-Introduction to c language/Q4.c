#include<stdio.h>
main(){
printf("* \n");
printf("* \n");
printf("* \n");
printf("*     * *       *\n");
printf("*    *   *     *\n");
printf("*   *     *   *\n");
printf("*  *       * *\n");
printf("* * \n");
printf("*             \n");
}
#include<stdio.h>
main(){
    int a,b ;
    a=8 , b=3; 
    if (a<b)
    {
        printf("minimum value :%d",a);
    }else{
        printf("minimum value :%d",b);
    }
   
}
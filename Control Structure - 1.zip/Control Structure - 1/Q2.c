#include<stdio.h>
main(){
    int a,b ;
    a=8 , b=3; 
    if (a>b)
    {
        printf("maximum value :%d",a);
    }else{
        printf("maximum value :%d",b);
    }
   
}
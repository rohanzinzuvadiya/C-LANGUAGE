#include<stdio.h>
main(){
    int l = 20 ;
    int a = l*l;
    printf("value of l :%d \n",l);
    printf("Area of Square is :%d",a);
}
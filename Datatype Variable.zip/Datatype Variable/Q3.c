#include<stdio.h>
main(){
    int a = 5 ;
    int b = 10 ;
    int c = a + b;
   printf("value of a :%d \n",a);
   printf("value of b :%d \n ",b);
   printf("Sum of a and b is :%d",c);
}
#include<stdio.h>
main(){
    int a = 200 ;
    int b = 20 ;
    int c = a/b ;
   printf("value of a :%d \n",a);
   printf("value of b :%d \n ",b);
   printf("Divison of a and b is :%d",c);
}
#include<stdio.h>
main(){
    int a = 10 ;
    int b = 20 ;
    int c = 30 ;
    int d = a + b + c ;
   printf("value of a :%d \n",a);
   printf("value of b :%d \n ",b);
   printf("value of c :%d \n ",c);
   printf("Sum of a and b and c is:%d",d);
}
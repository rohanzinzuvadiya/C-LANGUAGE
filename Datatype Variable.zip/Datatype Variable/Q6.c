#include<stdio.h>
main(){
    int a = 2 ;
    int b = 5 ;
    int c = 6 ;
    int d = 8 ;
    int e = a*b*c*d ;

   printf("value of a :%d \n",a);
   printf("value of b :%d \n ",b);
   printf("value of c :%d \n ",c);
   printf("value of d :%d \n ",d);
   printf("Multiply of a and b and c and d  is :%d",e);
}
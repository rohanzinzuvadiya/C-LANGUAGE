#include<stdio.h>
main(){
    int l = 20 ;
    int w = 50 ;
    int p = 2 * ( l + w );
   printf("value of l :%d \n",l);
   printf("value of w :%d \n ",w);
   printf("Perimeter of Rectengle is :%d",p);
}
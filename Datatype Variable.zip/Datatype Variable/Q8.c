#include<stdio.h>
main(){
    int l = 20 ;
    int p = 4*l;
   printf("value of l :%d \n",l);
   printf("Perimeter of Square is :%d",p);
}
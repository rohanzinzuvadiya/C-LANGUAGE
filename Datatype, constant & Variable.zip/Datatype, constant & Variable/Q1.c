#include<stdio.h>
main(){
    int hour , pay ;
    printf("enter no of hour:");
    scanf("%d",&hour);
    pay=hour*15;
    printf("weekly pay is $:%d",pay);
}
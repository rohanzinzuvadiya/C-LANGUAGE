#include<stdio.h>
main(){
int a,b ;
 printf("value of a :");
 scanf("%d",&a);
 printf("value of b :");
 scanf("%d",&b);
 printf("Product of a and b is :%d",a*b);
}
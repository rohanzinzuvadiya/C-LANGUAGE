#include<stdio.h>
main(){
float radious , area ;
 printf("value of radious :");
 scanf("%f",&radious);
 area = 3.14159*radious*radious;
 printf("the area of circle is : %0.2f",area);
}
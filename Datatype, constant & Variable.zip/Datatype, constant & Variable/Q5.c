#include<stdio.h>
main(){
int a,b,avg ;
 printf("value of a :");
 scanf("%d",&a);
 printf("value of b :");
 scanf("%d",&b);
avg=a+b;
printf("the average of a and b is :%d",avg/2);
}
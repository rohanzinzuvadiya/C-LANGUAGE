~#include<stdio.h>

main (){
   int first,second,third,ans;


    printf("First angle :");
    scanf("%d",&first);


    printf("Second angle :");
    scanf("%d",&second);

    third = 180 - first - second;

   
    

    printf("third angle : %d",third);

}
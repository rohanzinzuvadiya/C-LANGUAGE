#include<stdio.h>
main(){
int i =10;
while (i>=1)
{
printf("%d\n",i);
i--;
}

}
#include<stdio.h>
main(){
int i =1,n;
printf("Enter Number :");
scanf("%d",&n);
while (i<=n)
{
printf("%d\n",i);
i++;
}

}
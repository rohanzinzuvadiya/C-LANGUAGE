#include<stdio.h>

main(){
    

    for (int i = 10; i >=1; i--)
    {
        printf("%d\n",i);
    }
    
    
}
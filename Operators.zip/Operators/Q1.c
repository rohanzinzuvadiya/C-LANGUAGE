#include<stdio.h>
main(){
    int a,b,c;
    printf("Value of a is:");
    scanf("%d",&a);
    printf("Value of b is:");
    scanf("%d",&b);
    c=a+b;
    printf("Addition of a and b is :%d",c);
}
#include<stdio.h>
main(){
    int a,b,c,d;
    printf("Value of a is:");
    scanf("%d",&a);
    printf("Value of b is:");
    scanf("%d",&b);
    printf("Value of c is:");
    scanf("%d",&c);
    d=a+b+c;
    printf("Average of a and b and c is :%d",d/3);
}
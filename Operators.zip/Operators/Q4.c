#include<stdio.h>
main(){
    int a,b;
    printf("Value of a is:");
    scanf("%d",&a);
    b=a*a;
    printf("Square of a is :%d",b);
}
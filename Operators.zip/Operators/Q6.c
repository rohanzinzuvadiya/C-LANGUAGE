#include<stdio.h>
main(){
    int a,b;
    printf("Value of a  is:");
    scanf("%d",&a);
    b=a*a*a;
    printf("Power of a is :%d",b);
}






// //  Power  in Maths 
// #include<stdio.h>
// #include<math.h>
// int main(){
//    int a , b  ;
//    printf("value of Base : ");
//    scanf("%d",&a);
//    printf("value of exponent : ");
//    scanf("%d",&b);
//   int power =pow(a,b);
//    printf("the power of a is :%d",power);
//    return 0;
// }
#include<stdio.h>
main(){
    int a,b,c;
    printf("Value of Distance is:");
    scanf("%d",&a);
    printf("Value of Time is:");
    scanf("%d",&b);
    c=a/b;
    printf("Velocity of a and b is :%d m/s",c);
}
#include<stdio.h>
 main(){
    int a;
    a = (5+3)*(7-2);
   printf("%d",a);
}
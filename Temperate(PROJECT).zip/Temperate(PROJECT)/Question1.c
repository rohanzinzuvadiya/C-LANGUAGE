#include<stdio.h>

main(){
    char alfa = 'a';


    do
    {
        printf("%c ",alfa);

        alfa += 4;

    } while (alfa <= 'z');
    

}